package com.example.app_a_void

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp

class AppLimitSettingsFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return ComposeView(requireContext()).apply {
            setContent {
                AppLimitSettingsUI()
            }
        }
    }

    @Composable
    fun AppLimitSettingsUI() {
        // Sample data: list of apps
        val apps = listOf("App 1", "App 2", "App 3")
        val limits = remember { mutableStateMapOf<String, TextFieldValue>() }
        apps.forEach { app ->
            if (!limits.containsKey(app)) {
                limits[app] = TextFieldValue("0")
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            Text("Set App Usage Limits", style = MaterialTheme.typography.headlineMedium)

            apps.forEach { app ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(app, style = MaterialTheme.typography.bodyLarge)

                    TextField(
                        value = limits[app]!!,
                        onValueChange = { newValue -> limits[app] = newValue },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { /* Handle save logic here */ },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("Save Settings")
            }
        }
    }
}
