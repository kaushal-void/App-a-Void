package com.example.app_a_void

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class TimeWarpViewModelFactory(
    private val timeWarpLimitDao: TimeWarpLimitDao
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TimeWarpViewModel::class.java)) {
            return TimeWarpViewModel(timeWarpLimitDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
