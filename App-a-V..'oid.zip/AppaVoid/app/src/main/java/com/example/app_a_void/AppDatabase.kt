package com.example.app_a_void

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * Our Room database.
 * - Entities = [Task, TimeWarpLimit]
 * - version = 2 (bumped from 1 for schema changes)
 */
@Database(
    entities = [
        Task::class,
        TimeWarpLimit::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(TaskStatusConverter::class)
abstract class AppDatabase : RoomDatabase() {

    // Existing DAO
    abstract fun taskDao(): TaskDao

    // New DAO for Time Warp Limits
    abstract fun timeWarpLimitDao(): TimeWarpLimitDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * A thread-safe way to get the singleton instance of [AppDatabase].
         */
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                )
                    // For dev: automatically drop & recreate if schema changes
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
