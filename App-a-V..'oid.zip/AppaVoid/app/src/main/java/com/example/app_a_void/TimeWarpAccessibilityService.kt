package com.example.app_a_void

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class TimeWarpAccessibilityService : AccessibilityService() {

    override fun onCreate() {
        super.onCreate()
        Log.d("TimeWarpAccessibility", "Service created.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // This method is called whenever an accessibility event occurs
        // We’ll detect the currently foreground app in future steps
        Log.d("TimeWarpAccessibility", "Received an event: $event")
    }

    override fun onInterrupt() {
        // Called when the system *interrupts* this service
        // (e.g., when accessibility service is disabled)
        Log.d("TimeWarpAccessibility", "Service interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("TimeWarpAccessibility", "Service destroyed.")
    }
}
