package com.example.app_a_void

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

/**
 * The main screen for Time Warp settings.
 * - usageStatsList: The list of AppUsageStats from your UsageStatsHelper
 * - timeWarpViewModel: The ViewModel that loads/saves limits
 * - onBackClick: callback for a "Back" button
 */
@Composable
fun TimeWarpSettingsScreen(
    usageStatsList: List<AppUsageStats>,
    timeWarpViewModel: TimeWarpViewModel,
    onBackClick: () -> Unit
) {
    // 1) Collect the current DB list of TimeWarpLimit
    val dbLimits by timeWarpViewModel.limits.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = onBackClick) {
                Text(text = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "Time Warp Settings",
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2) For each usageStats entry, find the matching limit (if any) in dbLimits
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(usageStatsList) { appUsage ->
                // Attempt to find a matching TimeWarpLimit
                val existingLimit = dbLimits.firstOrNull {
                    it.packageName == appUsage.packageName
                }
                // Pass that limit to the row
                TimeWarpAppItem(
                    appUsage = appUsage,
                    timeWarpViewModel = timeWarpViewModel,
                    existingLimit = existingLimit
                )
            }
        }
    }
}

/**
 * A single row that shows:
 * - The app's icon + usage time
 * - An OutlinedTextField to input a new limit (in minutes)
 * - A "Save Limit" button that calls timeWarpViewModel.saveLimit
 * - A "Current Limit" label that displays the DB limit if found
 */
@Composable
fun TimeWarpAppItem(
    appUsage: AppUsageStats,
    timeWarpViewModel: TimeWarpViewModel,
    existingLimit: TimeWarpLimit?
) {
    var limitInput by remember { mutableStateOf("") }

    // Show the DB limit if it exists, else "None"
    val currentLimitText = existingLimit?.limit ?: "None"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        // Icon + name/time
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.avatar_placeholder),
                contentDescription = appUsage.appName,
                modifier = Modifier
                    .height(40.dp)
                    .padding(end = 8.dp)
            )
            Text(
                text = "${appUsage.appName} - ${appUsage.formattedTime}",
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input for new limit
        OutlinedTextField(
            value = limitInput,
            onValueChange = { limitInput = it },
            label = { Text("Limit (min)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // "Save Limit" + "Current Limit: ..."
        Row(horizontalArrangement = Arrangement.SpaceBetween) {
            Button(
                onClick = {
                    val minutes = limitInput.toLongOrNull() ?: 0L
                    val limitToSave = TimeWarpLimit(
                        packageName = appUsage.packageName,
                        appName = appUsage.appName,
                        limit = "$minutes min"
                    )
                    timeWarpViewModel.saveLimit(limitToSave)
                    limitInput = ""
                }
            ) {
                Text("Save Limit")
            }

            Text(
                text = "Current Limit: $currentLimitText",
                color = Color.White
            )
        }
    }
}
