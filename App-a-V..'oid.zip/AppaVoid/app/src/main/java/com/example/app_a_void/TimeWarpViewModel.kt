package com.example.app_a_void

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class TimeWarpViewModel(private val dao: TimeWarpLimitDao) : ViewModel() {

    // Backing StateFlow of all TimeWarpLimit records
    private val _limits = MutableStateFlow<List<TimeWarpLimit>>(emptyList())
    val limits: StateFlow<List<TimeWarpLimit>> = _limits

    init {
        loadLimits()
    }

    // Collect from the DAO and update our StateFlow
    private fun loadLimits() {
        viewModelScope.launch {
            dao.getAllLimits().collect { listOfLimits ->
                _limits.value = listOfLimits
            }
        }
    }

    // Insert or replace a limit record
    fun saveLimit(timeWarpLimit: TimeWarpLimit) {
        viewModelScope.launch {
            Log.d("TimeWarpViewModel", "Attempting to save limit: ${timeWarpLimit.limit} for ${timeWarpLimit.appName}")
            dao.insertLimit(timeWarpLimit)
            Log.d("TimeWarpViewModel", "Limit saved")
        }
    }

    // Example if you want to retrieve a single limit
    fun getLimitByPackageName(packageName: String) {
        viewModelScope.launch {
            dao.getLimitByPackage(packageName).collect { limit ->
                // Process it as needed...
            }
        }
    }
}
